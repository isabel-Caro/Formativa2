package com.example.formativa2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.formativa2.adaptadores.UsuarioAdaptador;
import com.example.formativa2.clases.Usuario;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv_usuarios;
    List<Usuario> listaUsuario = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        rcv_usuarios = findViewById(R.id.rcv_usuarios);

        Usuario usu1 = new Usuario("https://i.pinimg.com/736x/19/c8/af/19c8afd381be6052d9e2066e51bccc9d.jpg","carolina","ingSistema");
        Usuario usu2 = new Usuario("https://tse2.mm.bing.net/th?id=OIP.R8n1Dtcb0HAve_cxCTAUuwHaIN&pid=Api&P=0&h=180","isabel","copito");
        Usuario usu3 = new Usuario("https://tse1.mm.bing.net/th?id=OIP.KQm2sPfTfztWi6iCEgVeSgHaFj&pid=Api&P=0&h=180","vergel","amarillo");
        Usuario usu4 = new Usuario("https://wallpaperaccess.com/full/540472.jpg","perez","carro");

        listaUsuario.add(usu1);
        listaUsuario.add(usu2);
        listaUsuario.add(usu3);
        listaUsuario.add(usu4);

        rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));
        rcv_usuarios.setAdapter(new UsuarioAdaptador(listaUsuario));

    }
}